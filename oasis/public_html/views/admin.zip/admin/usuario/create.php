<?php
    $titulo = 'Crear Usuario'; 
    include 'php/cabecera.php'; 
    include $URL.'php/menu-admin.php';
?>
    <?php if(isset($this->msj)){
            if($this->msj == true){
    ?>
        <div class="row d-flex justify-content-center">
            <h2 class="text-success m-3">Usuario Agregada</h2>
        </div>
    <?php } else{?>            
        <div class="row d-flex justify-content-center">
            <h2 class="text-danger m-3">No se agrego</h2>
        </div>
    <?php }}?>
    <div class="row d-flex justify-content-center">
        <h2 class="text-success m-3">Agregar Usuario</h2>
    </div>

    <div class="row d-flex justify-content-center m-5">

        <form class="w-75" action="<?php print constant('URL'); ?>admin/usuario_insert" method="POST">
           <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" class="form-control" id="nombre" name="nombre" aria-describedby="textHelp" placeholder="Ingresa tu nombre">
            </div>
            <div class="form-group">
                <label for="apellido">Apellido</label>
                <input type="text" class="form-control" id="apellido" name="apellido" aria-describedby="textHelp" placeholder="Ingresa tu apellido">
            </div>
            <div class="form-group">
                <label for="usuario">Usuario</label>
                <input type="text" class="form-control" id="usuario" name="usuario" aria-describedby="textHelp" placeholder="Ingresa tu usuario" required>
            </div>
            <div class="form-group">
                <label for="contrasena">Contrsaeña</label>
                <input type="password" class="form-control" id="contrasena" name="contrasena" aria-describedby="textHelp" placeholder="Ingresa tu contraseña" required>
            </div>
 
            <div class="row d-flex justify-content-center">
                <input type="submit" value="Agregar" class="btn btn-success">
            </div>
        </form>

    </div>

    <div class="row d-flex justify-content-center">
        <button type="button" class="btn btn-success m-4"><a class="badge badge-success" href="#">Agregar fotografia</a></button>
    </div>
<?php
    include $URL.'html/body-final.html';  
?>
