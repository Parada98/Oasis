<?php
    $titulo = 'Administrar Venta';
    require_once $URL.'php/cabecera.php'; 
    require_once $URL.'php/menu-admin.php';
    ?>
    <h2 class="text-center m-4">Inventario</h2>
    <div class="row d-flex justify-content-center">
        <table class="table w-75 table-borderless table-light align-middle text-center" style="color:#FFF;" >
            <thead style="background: #0E698B;" >
                <tr>
                    <th scope="col">Nombre del libro</th>
                    <th scope="col">Nombre del usuario</th>
                    <th scope="col">Direccion</th>
                    <th scope="col">RFC</th>
                    <th scope="col">precio</th>
                    <th scope="col">Cantidad</th>
                    <th scope="col">Total</th>
                    <th scope="col">credito</th>
                </tr>
            </thead>
            <tbody style="background: #253854;">
            <?php 
                foreach($this->datos as $item)
                {
                    print <<<"__datos"
                        \t\t\t\t<tr>
                        \t\t\t\t\t<td>$item[nombre_libro]</td>
                        \t\t\t\t\t<td>$item[nombre_usuario]</td>
                        \t\t\t\t\t<td>$item[direccion]</td>
                        \t\t\t\t\t<td>$item[rfc]</td>
                        \t\t\t\t\t<td>$item[precio]</td>
                        \t\t\t\t\t<td>$item[cantidad]</td>
                        \t\t\t\t\t<td>$item[total]</td>
                        \t\t\t\t\t<td>$item[credito]</td>
                        \t\t\t\t<tr>\n
                    __datos;
                }
            ?>
            <tbody>
        </table>
    </div>

<?php
    require_once $URL.'html/body-final.html';
?>
