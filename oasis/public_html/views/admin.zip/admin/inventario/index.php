<?php
    $titulo = 'Administrar Inventario';
    require_once $URL.'php/cabecera.php'; 
    require_once $URL.'php/menu-admin.php';
    print "\t\t\t<section class='post'>";
    
    ?>
    <h2 class="text-center m-4">Inventario</h2>
    <div class="row d-flex justify-content-center">
    <div class="row d-flex justify-content-center">
        <table class="table w-75 table-borderless table-light align-middle text-center" style="color:#FFF;" >
            <thead style="background: #0E698B;" >
                <tr>
                    <th scope="col">Nombre del libro</th>
                    <th scope="col">stock</th>
                    <th scope="col">Fecha de ingreso</th>
                    <th scope="col">Actualizar</th>
                </tr>
            </thead>
            <tbody style="background: #253854;  ">
            <?php 
                foreach($this->datos as $item)
                {
                    print <<<"__datos"
                        \t\t\t\t<tr>
                        \t\t\t\t\t<td>$item[nombre]</td>
                        \t\t\t\t\t<td>$item[stock]</td>
                        \t\t\t\t\t<td>$item[fecha]</td>
                        \t\t\t\t\t<td><form class="w-75" action="inventario_update" method="POST"><button type="submit" class="btn btn-info " name='id_inventario' value='$item[id_inventario]'>Actualizar</button></form></td>
                        \t\t\t\t<tr>\n
                    __datos;
                }
            ?>
            <tbody>
        </table>
    </div>

<?php
    require_once $URL.'html/body-final.html';
?>
