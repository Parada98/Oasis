<?php
    function conexion($host ,$dbname ,$user , $password)
    {
        try{
            $GLOBALS['db'] = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
            $GLOBALS['db']->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }catch(PDOException $e){
            $GLOBALS['msg'] = 'Fallo la conexion';
        }
    }
    $titulo = 'Crear  Inventario'; 
    include 'php/cabecera.php'; 
    include $URL.'php/menu-admin.php';
    ?>
    <?php if(isset($this->msj)){
        if($this->msj == true){
            ?>
        <div class="row d-flex justify-content-center">
            <h2 class="text-success m-3">Agregada</h2>
        </div>
    <?php } else{?>            
        <div class="row d-flex justify-content-center">
            <h2 class="text-danger m-3">No se agrego</h2>
        </div>
    <?php }}?>
    <div class="row d-flex justify-content-center">
        <h2 class="text-success m-3">Agregar</h2>
    </div>

    <div class="row d-flex justify-content-center m-5">

        <form class="w-75" action="<?php print constant('URL'); ?>admin/inventario_insert" method="POST">
            <div class="form-group">
                <label for="nombre">Nombre</label>
                <select name="id_libro">
                <?php
                    conexion(constant('HOST'), constant('DB'), constant('USER'), constant('PASSWORD'));
                    $consulta = $GLOBALS['db']->prepare("SELECT DISTINCT * FROM  Libro ORDER BY nombre");
                    $consulta->execute();
                    while($fila = $consulta->fetch())
                    print PHP_EOL."\t\t\t\t\t".'<option value="'.$fila['id_libro'].'">'.$fila['nombre'].'</option>';
                    $GLOBALS['db'] = null;
                    $consulta = null;        
                    ?>
                </select>

            </div>
            <div class="form-group">
                <label for="stock">stock</label>
                <input type="number"  min="0" step="1" class="form-control" id="stock" name="stock" aria-describedby="textHelp" placeholder="Ingresa el numero de libros" required>
            </div>
            <div class="row d-flex justify-content-center">
                <input type="submit" value="Agregar" class="btn btn-success">
            </div>
        </form>
    </div>
<?php
    include $URL.'html/body-final.html';  
?>
