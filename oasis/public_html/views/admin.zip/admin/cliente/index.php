<?php
    $titulo = 'Administrar Ciente';
    require_once $URL.'php/cabecera.php'; 
    require_once $URL.'php/menu-admin.php';
    print "\t\t\t<section class='post'>";
    
    ?>
    <?php if(isset($this->msj)){
            if($this->msj == true){
    ?>
        <div class="row d-flex justify-content-center">
            <h2 class="text-success m-3">Cliente Elimnada</h2>
        </div>
    <?php } else{?>            
        <div class="row d-flex justify-content-center">
            <h2 class="text-danger m-3">Error al eliminar</h2>
        </div>
    <?php }}?>
    <h2 class="text-center m-4">Cliente</h2>
    <div class="row d-flex justify-content-center">
        <table class="table w-75 table-borderless table-light align-middle text-center" style="color:#FFF;" >
            <thead style="background: #0E698B;" >                <tr>
                <th scope="col">Nombre</th>
                <th scope="col">Apellido</th>
                <th scope="col">RFC</th>
                <th scope="col">Credito</th>
                <th scope="col">Actualizar</th>
                <th scope="col">Eliminar</th>
                </tr>
            </thead>
            <tbody style="background: #253854;">
            <?php 
                foreach($this->datos as $item )
                {
                    // no mms es mi perra
                    print <<<"__datos"
                        \t\t\t\t<tr>
                        \t\t\t\t\t<td>$item[nombre]</td>
                        \t\t\t\t\t<td>$item[apellido]</td>
                        \t\t\t\t\t<td>$item[rfc]</td>
                        \t\t\t\t\t<td>$item[credito]</td>
                        \t\t\t\t\t<td><form class="w-75" action="cliente_update" method="POST"><button type="submit" class="btn btn-info " name='id_cliente' value='$item[id_cliente]'>Actualizar</button></form></td>
                        \t\t\t\t\t<td><form class="w-75" action="cliente_remove" method="POST"><button type="submit" class="btn btn-danger " name='id_cliente' value='$item[id_cliente]'>Eliminar</button></form></td>
                        \t\t\t\t<tr>\n
                    __datos;
                }
            ?>
            <tbody>
        </table>
    </div>
    <div class="row d-flex justify-content-center">
        <button type="button" class="btn btn-success m-4"><a class="badge badge-success" href="<?php print constant('URL'); ?>admin/cliente_create">Agregar</a></button>
    </div>

<?php
    require_once $URL.'html/body-final.html';
?>
