<?php
    $titulo = 'Actualizar Cliente';
    include 'php/cabecera.php'; 
    include $URL.'php/menu-admin.php';
    if(isset($this->datos)){
        // que campos teniamos para actualizar
        // nombre, apellido, usuario?? solo 3
        foreach($this->datos as $item){
            print 
            $id_cliente = $item['id_cliente'];
            $nombre = $item['nombre'];
            $apellido = $item['apellido'];
            $rfc = $item['rfc'];
            $credito = $item['credito'];
        }
    }
    // somo la vrg!!, de huevos
    // faltan 2 tablas...
    // libro y que <mas class=""></mas>
    // ptm, ya no quiero ya no quiero
    // falta libro en el menu
    // tambien inventario
?>
    <?php if(isset($this->msj)){
            if($this->msj == true){
    ?>
        <div class="row d-flex justify-content-center">
            <h2 class="text-success m-3">Actualizacion Relizada</h2>
        </div>
    <?php } else{?>            
        <div class="row d-flex justify-content-center">
            <h2 class="text-danger m-3">No se pudo Actualizar</h2>
        </div>
    <?php }}?>
    <div class="row d-flex justify-content-center">
        <h2 class="text-success m-3">Actualizar Cliente</h2>
    </div>

    <div class="row d-flex justify-content-center m-5">

        <form class="w-75" action="<?php print constant('URL'); ?>admin/cliente_update2" method="POST">
            <div class="form-group">
                <label for="id_cliente">Id clienet</label>
                <input type="text" class="form-control" value='<?php print $id_cliente; ?>'  id="id_cliente" name="id_cliente" aria-describedby="textHelp" readonly>
            </div>
            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" class="form-control" value='<?php print $nombre; ?>' id="nombre" name="nombre" aria-describedby="textHelp" placeholder="Ingresa tu nombre" required>
            </div>
            <div class="form-group">
                <label for="apellido">Apellido</label>
                <input type="text" class="form-control" value='<?php print $apellido; ?>' id="apellido" name="apellido" aria-describedby="textHelp" placeholder="Ingresa tu apellido" required>
            </div>
            <div class="form-group">
                <label for="rfc">RFC</label>
                <input type="text" class="form-control" value='<?php print $rfc; ?>' id="rfc" name="rfc" aria-describedby="textHelp" placeholder="Ingresa tu rfc" required>
            </div>
            <div class="form-group">
                <label for="credito">Credito</label>
                <!-- // nos va a falta una validacion con javascript, para credito, que no almita mas que si y no -->
                <!-- no mms como se escribe -->
                <input list="creditos" class="form-control" value='<?php print $credito; ?>' id="credito" name="credito" aria-describedby="textHelp" placeholder="Ingresa credito">
                    <datalist id="creditos">
                        <option value="si">
                        <option value="no">
                    </datalist>
                    <!-- hajaja -->
            </div>
            <div class="row d-flex justify-content-center">
                <input type="submit" value="Actualizar" class="btn btn-success">
            </div>
        </form>

    </div>
    <!-- //veamoslo, veamoslo brillar -->

<?php
    include $URL.'html/body-final.html';  
?>
