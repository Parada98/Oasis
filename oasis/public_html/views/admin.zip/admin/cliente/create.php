<?php
    $titulo = 'Crear Cliente'; 
    include 'php/cabecera.php'; 
    include $URL.'php/menu-admin.php';
?>
    <?php if(isset($this->msj)){
            if($this->msj == true){
    ?>
        <div class="row d-flex justify-content-center">
            <h2 class="text-success m-3">Ciente Agregada</h2>
        </div>
    <?php } else{?>            
        <div class="row d-flex justify-content-center">
            <h2 class="text-danger m-3">No se agrego</h2>
        </div>
    <?php }}?>
    <div class="row d-flex justify-content-center">
        <h2 class="text-success m-3">Agregar Cliente</h2>
    </div>

    <div class="row d-flex justify-content-center m-5">

<!-- // si queda de una, el diego nos da unos mames!! -->
<!-- neta nada gay, no te veo a los ojos -->
<!-- el gordo nos los da -->
        <form class="w-75" action="<?php print constant('URL'); ?>admin/cliente_insert" method="POST">
           <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" class="form-control" id="nombre" name="nombre" aria-describedby="textHelp" placeholder="Ingresa tu nombre" required>
            </div>
            <div class="form-group">
                <label for="apellido">Apellido</label>
                <input type="text" class="form-control" id="apellido" name="apellido" aria-describedby="textHelp" placeholder="Ingresa tu apellido" required>
            </div>
            <div class="form-group">
                <label for="rfc">RFC</label>
                <input type="text" class="form-control" id="rfc" name="rfc" aria-describedby="textHelp" placeholder="Ingresa tu rfc" required>
            </div>
            <div class="form-group">
                <label for="credito">Credito</label>
                <!-- // nos va a falta una validacion con javascript, para credito, que no almita mas que si y no -->
                <!-- no mms como se escribe -->
                <input list="creditos" class="form-control" id="credito" name="credito" aria-describedby="textHelp" placeholder="Ingresa credito">
                    <datalist id="creditos">
                        <option value="si">
                        <option value="no">
                    </datalist>
                    <!-- hajaja -->
            </div>
 <!-- cool falta una -->
            <div class="row d-flex justify-content-center">
                <input type="submit" value="Agregar" class="btn btn-success">
            </div>
        </form>
<!-- tfo bienmmmm..................................... pero no lo modica el usuaeio -->
    </div>
<?php
    include $URL.'html/body-final.html';  
?>
