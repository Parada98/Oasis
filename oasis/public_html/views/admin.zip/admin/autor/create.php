<?php
    $titulo = 'Crear  Autor'; 
    include 'php/cabecera.php'; 
    include $URL.'php/menu-admin.php';
    ?>
    <?php if(isset($this->msj)){
        if($this->msj == true){
            ?>
        <div class="row d-flex justify-content-center">
            <h2 class="text-success m-3">Autor Agregada</h2>
        </div>
    <?php } else{?>            
        <div class="row d-flex justify-content-center">
            <h2 class="text-danger m-3">No se agrego</h2>
        </div>
    <?php }}?>
    <div class="row d-flex justify-content-center">
        <h2 class="text-success m-3">Agregar Autor</h2>
            <style>
                @media only screen and (max-width: 700px) {
                    video {
                        max-width: 100%;
                    }
                }
            </style>
    </div>

    <div class="row d-flex justify-content-center m-5">

        <form class="w-75" action="<?php print constant('URL'); ?>admin/autor_insert" method="POST">
            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" class="form-control" id="nombre" name="nombre" aria-describedby="textHelp" placeholder="Ingresa el nombre" required>
            </div>
            <div class="form-group">
                <label for="edad">Edad</label>
                <input type="number"  min="10" max="150" step="1" class="form-control" id="edad" name="edad" aria-describedby="textHelp" placeholder="Ingresa la edad" required>
            </div>
            <div class="form-group">
                <label for="genero">Genero</label>
                <input type="text" class="form-control" id="genero" name="genero" aria-describedby="textHelp" placeholder="Ingresa el genero" required>
            </div>
            <div class="row d-flex justify-content-center">
                <input type="submit" value="Agregar" class="btn btn-success">
            </div>
        </form>

    </div>
    <div class="row d-flex justify-content-center">
        <button type="button" class="btn btn-success m-4"><a class="badge badge-success" href="#">Agregar fotografia</a></button>
    </div>
<?php
    include $URL.'html/body-final.html';  
?>
