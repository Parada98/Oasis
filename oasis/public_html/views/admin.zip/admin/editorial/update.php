<?php
    $titulo = 'Actualizar Editorial';
    include 'php/cabecera.php'; 
    include $URL.'php/menu-admin.php';
    
    if(isset($this->datos)){
        foreach($this->datos as $editorial){
            $id_editorial = $editorial['id_editorial'];
            $nombre = $editorial['nombre'];
            $direccion = $editorial['direccion'];
            $decripcion = isset($editorial['descripcion']) ? $editorial['descripcion'] : '';
        }
    }
?>
    <?php if(isset($this->msj)){
            if($this->msj == true){
    ?>
        <div class="row d-flex justify-content-center">
            <h2 class="text-success m-3">Actualizacion Relizada</h2>
        </div>
    <?php } else{?>            
        <div class="row d-flex justify-content-center">
            <h2 class="text-danger m-3">No se pudo Actualizar</h2>
        </div>
    <?php }}?>
    <div class="row d-flex justify-content-center">
        <h2 class="text-success m-3">Agregar Editorial</h2>
    </div>

    <div class="row d-flex justify-content-center m-5">

        <form class="w-75" action="<?php print constant('URL'); ?>admin/editorial_update2" method="POST">
            <div class="form-group">
                <label for="id_usuario">Id usuario</label>
                <input type="text" class="form-control" value='<?php print $id_editorial; ?>'  id="id_editorial" name="id_editorial" aria-describedby="textHelp" readonly>
            </div> <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" class="form-control" value='<?php print $nombre; ?>' id="nombre" name="name" aria-describedby="textHelp" placeholder="Ingresa tu nombre" required>
            </div>
            <div class="form-group">
                <label for="direccion">Direccion</label>
                <input type="text" class="form-control" value='<?php print $direccion; ?>' id="direccion" name="direccion" aria-describedby="textHelp" placeholder="Ingresa tu dirreccion" required>
            </div>
            <div class="form-group">
                <label for="Descripcion">Descripcion</label>
                <input type="text" class="form-control" value='<?php print $decripcion; ?>' id="descripcion" name="descripcion" aria-describedby="textHelp" placeholder="Ingresa una descripcion">
            </div>
            <div class="row d-flex justify-content-center">
                <input type="submit" value="Actualizar" class="btn btn-success">
            </div>
        </form>

    </div>
<?php
    include $URL.'html/body-final.html';  
?>
