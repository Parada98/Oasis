<?php
    $titulo = 'Administrar libro';
    require_once $URL.'php/cabecera.php'; 
    require_once $URL.'php/menu-admin.php';
    
    ?>
    <?php if(isset($this->msj)){
            if($this->msj == true){
    ?>
        <div class="row d-flex justify-content-center">
            <h2 class="text-success m-3">Libro Elimnada</h2>
        </div>
    <?php } else{?>            
        <div class="row d-flex justify-content-center">
            <h2 class="text-danger m-3">Error al eliminar</h2>
        </div>
    <?php }}?>
    <h2 class="text-center m-4">Libro</h2>
    <div class="row d-flex justify-content-center">
        <table class="table w-75 table-borderless table-light align-middle text-center" style="color:#FFF;" >
            <thead style="background: #0E698B;" >
                <tr>
                    <th scope="col">Nombre</th>
                    <th scope="col">Color</th>
                    <th scope="col">Estante</th>
                    <th scope="col">numero de paginas</th>
                    <th scope="col">Descripcion </th>
                    <th scope="col">Estado</th>
                    <th scope="col">Precio</th>
                    <th scope="col">Autor</th>
                    <th scope="col">Editorial</th>
                    <th scope="col">Actualizar</th>
                    <th scope="col">Eliminar</th>
                </tr>
            </thead>
            <tbody style="background: #253854;">
            <?php 
            // var_dump($this->datos);
                foreach($this->datos as $item )
                {
                    print <<<"__datos"
                        \t\t\t\t<tr>
                        \t\t\t\t\t<td>$item[nombre]</td>
                        \t\t\t\t\t<td>$item[color]</td>
                        \t\t\t\t\t<td>$item[estante]</td>
                        \t\t\t\t\t<td>$item[numero_paginas]</td>
                        \t\t\t\t\t<td>$item[descripcion]</td>
                        \t\t\t\t\t<td>$item[estado]</td>
                        \t\t\t\t\t<td>$ $item[precio]</td>
                        \t\t\t\t\t<td>$item[autor]</td>
                        \t\t\t\t\t<td>$item[editorial]</td>
                        \t\t\t\t\t<td><form class="w-75" action="libro_update" method="POST"><button type="submit" class="btn btn-info " name='id_libro' value='$item[id_libro]'>Actualizar</button></form></td>
                        \t\t\t\t\t<td><form class="w-75" action="libro_remove" method="POST"><button type="submit" class="btn btn-danger " name='id_libro' value='$item[id_libro]'>Eliminar</button></form></td>
                        \t\t\t\t<tr>\n
                    __datos;
                }
            ?>
            <tbody>
        </table>
    </div>
    <div class="row d-flex justify-content-center">
        <button type="button" class="btn btn-success m-4"><a class="badge badge-success" href="<?php print constant('URL'); ?>admin/libro_create">Agregar</a></button>
    </div>

<?php
    require_once $URL.'html/body-final.html';
?>
<!-- ya es todo aqui? -->